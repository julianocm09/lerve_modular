<?php

namespace Modules\TesteNeurodivergencia\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Modules\TesteNeurodivergencia\Models\TesteNeurodivergencia;
use Barryvdh\DomPDF\Facade\Pdf;

class TesteNeurodivergenciaController extends Controller
{
    public function index()
    {
        return view('TesteNeurodivergencia::hello');
    }





   public function submitForm(Request $request) {
    $data = $request->validate([
        'name' => 'required|string',
        'email' => 'required|email',
        'answers' => 'required|array',
    ]);

    // Inicializa as pontuações
    $scores = [
        'TDAH' => 0,
        'TEA' => 0,
        'TOD' => 0,
        'Processamento Sensorial' => 0,
        'Dislexia/Ansiedade Social' => 0,
    ];

    // Faz a contagem
    foreach ($data['answers'] as $key => $value) {
        $val = intval($value);

        if (str_contains($key, 'tdah')) $scores['TDAH'] += $val;
        if (str_contains($key, 'tea')) $scores['TEA'] += $val;
        if (str_contains($key, 'tod')) $scores['TOD'] += $val;
        if (str_contains($key, 'sensorial')) $scores['Processamento Sensorial'] += $val;
        if (str_contains($key, 'dislexia')) $scores['Dislexia/Ansiedade Social'] += $val;
    }

    arsort($scores);
    $result = array_key_first($scores); // Maior pontuação

    // Salva no banco
    $test = TesteNeurodivergencia::create([
        'name' => $data['name'],
        'email' => $data['email'],
        'answers' => json_encode($data['answers']),
        'scores' => json_encode($scores),
        'diagnosis' => $result,
    ]);

    return view('result', [
        'test' => $test,
        'scores' => $scores,
        'result' => $result,
    ]);
}
   public function gerarPdf(Request $request)
{
    $data = $request->validate([
        'test' => 'required|array',
        'scores' => 'required|array',
        'result' => 'required|string',
        'respostas' => 'required|array',
        'questions' => 'required|array',
    ]);

    $pdf = Pdf::loadView('TesteNeurodivergencia::resultado', $data);
    return $pdf->download('resultado_teste.pdf');
}
}

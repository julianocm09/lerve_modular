<?php

namespace Modules\TesteNeurodivergencia\Models;

use Illuminate\Database\Eloquent\Model;

class TesteNeurodivergencia extends Model
{
    protected $guarded = [];
}

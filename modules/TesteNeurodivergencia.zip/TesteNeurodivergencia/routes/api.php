<?php

use Illuminate\Support\Facades\Route;

// Rotas API do módulo TesteNeurodivergencia
